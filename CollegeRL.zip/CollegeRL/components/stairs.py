class Stairs:
    def __init__(self, floor):
        self.floor = floor